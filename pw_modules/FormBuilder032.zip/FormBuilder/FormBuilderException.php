<?php

/**
 * ProcessWire Form Builder Exception
 *
 * Copyright (C) 2016 by Ryan Cramer Design, LLC
 * 
 * PLEASE DO NOT DISTRIBUTE
 * 
 */

class FormBuilderException extends Exception { }

