<?php namespace ProcessWire;

if(!defined("PROCESSWIRE")) die();

/**
 * ProMailer: useful hooks for your /site/ready.php file
 * 
 * Do not replace your /site/ready.php with this file, instead copy/paste
 * any hooks you want to use into that file. We will be adding more hooks to
 * this file as they come up. 
 * 
 */

/** @var ProMailer $promailer */

/**
 * Mailgun analytics hook (via @jens.martsch)
 * 
 * To enable Mailgun analytics for different newsletters/mails, you can use tags, 
 * in this case using the email subject as a tag for analytics/tracking in Mailgun. 
 * This hook requires the WireMailMailgun module to be installed. More about 
 * Mailgun tags can be found here: 
 * 
 * https://documentation.mailgun.com/en/latest/user_manual.html#tagging
 * 
 */
$promailer->addHookAfter('ProMailerEmail::subscriberMessageReady', function(HookEvent $event) {
	/** @var array $data */
	$data = $event->arguments(0);
	/** @var WireMail $mailer */
	$mailer = $data['mailer'];
	if($mailer->className() == 'WireMailMailgun') {
		$mailer->addTag($data['subject']);
	}
}); 
