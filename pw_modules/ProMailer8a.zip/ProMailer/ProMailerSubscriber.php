<?php namespace ProcessWire;

/**
 * ProMailer Subscriber
 * 
 * @property int $id
 * @property int $list_id
 * @property string $email
 * @property string $type Either ProMailer::listTypeRegular or ProMailer::listTypePages
 * @property Page|null $page Pages associated with subscriber if type is ProMailer::listTypePages
 * @property int $flags
 * @property array $custom
 * @property string $code Confirmation code for this subscriber, used for confirming subscribe/unsubscribe
 * @property int $confirmed Is subscriber opt-in confirmed? Contains timestamp of confirmation time when confirmed
 * @property int $created Timestamp of when this subscriber was created
 * @property int $num_sent Number of messages sent to this subscriber
 * @property int $num_bounce Number of bounces for this subscriber
 * 
 * // aliased properties
 * @property ProMailerList|null $list List that this subscriber belongs to
 * 
 */
class ProMailerSubscriber extends ProMailerType {
	public function getDefaultsArray() {
		return array(
			'type' => '', // blank or 'pages'
			'page' => null,
			'id' => 0,
			'list_id' => 0,
			'flags' => 0,
			'email' => '',
			'custom' => array(),
			'code' => '',
			'confirmed' => 0,
			'created' => 0,
			'num_sent' => 0,
			'num_bounce' => 0
		);
	}
	
	protected $list = null;

	/**
	 * Get the list this subscriber belongs to
	 * 
	 * @return ProMailerList|null
	 * 
	 */
	public function getList() {
		if($this->list) return $this->list;
		$list_id = $this->get('list_id');
		$this->list = $list_id ? $this->manager->lists->get($list_id) : null;
		return $this->list;
	}

	/**
	 * Set the list for this subscriber
	 * 
	 * @param ProMailerList $list
	 * @return $this
	 * @throws WireException
	 * 
	 */
	public function setList(ProMailerList $list) {
		parent::set('list_id', (int) $list->id);
		$this->list = $list;
		return $this;
	}

	public function get($key) {
		if($key === 'list') return $this->getList();
		return parent::get($key);
	}
	
	public function set($key, $value) {
		if($key === 'list') return $this->setList($value);
		if($key === 'list_id' && $this->list) $this->list = null;
		if($key === 'email' && strlen($value)) $value = $this->wire('sanitizer')->email($value);
		return parent::set($key, $value);
	}
	
	public function gravatar($size = 80, $attr = '') {
		$useGravatar = $this->manager->promailer->useGravatar; 
		if($useGravatar === ProMailer::useGravatarNone) return '';
		if(strpos($attr, 'alt=') === false) $attr = trim("alt='' $attr");
		$url = "https://www.gravatar.com/avatar/" . md5(strtolower(trim($this->email))) . "?s=" . $size . "&d=$useGravatar";
		$img = "<img src='$url' $attr />";
		return $img;
	}
	
	public function getCustom($name) {
		$custom = parent::get('custom');
		return isset($custom[$name]) ? $custom[$name] : null;
	}

	/**
	 * Set value for custom field while also sanitizing it 
	 * 
	 * @param string $name
	 * @param mixed $value
	 * @return bool Returns true if value was a custom field and modified, false if not
	 * 
	 */
	public function setCustom($name, $value) {
		
		/** @var Sanitizer $sanitizer */
		$sanitizer = $this->wire('sanitizer');
		
		$list = $this->getList();
		$fields = $list->fields;
		
		if(!isset($fields[$name])) {
			$this->set($name, $value);
			return false;
		}
		
		$field = $fields[$name];
		$type = $field['type'];
		$custom = $this->get('custom');
	
		try {
			if($type === 'option' || $type === 'options') {
				$value = $sanitizer->$type($value, array_keys($field['options']));
			} else {
				$value = $sanitizer->$type($value);
			}
		} catch(\Exception $e) {
			$value = $sanitizer->text($value);
		}
		
		if((!isset($custom[$name]) && !empty($value)) || (isset($custom[$name]) && $custom[$name] != $value)) {
			$custom[$name] = $value;
			$this->set('custom', $custom);
			$this->trackChange($name);
			return true;
		} else {
			return false;
		}
	}
	
}