ProcessWire ProMailer 
=====================

Copyright 2019 by Ryan Cramer Design, LLC
This is a commercial module, please do not distribute. 

Thank you for purchasing ProMailer! 

Documentation:
https://processwire.com/store/pro-mailer/manual/

Support forum: 
https://processwire.com/talk/forum/50-promailer-support/


Install
-------
1. Copy all the files for this module into /site/modules/ProMailer/.
2. In your admin, go to Modules > Refresh. 
3. Click Install for the ProMailer module. 


How to setup use ProMailer
--------------------------
The full manual documentation is available at this url:
https://processwire.com/store/pro-mailer/manual/

If you are just getting started, I recommend at least reading the “Setting up and 
using ProMailer” section when using ProMailer for the first time.

Changelog
---------
ProMailer v8 (22 June 2019)
- Fix issue in subscribers with non-"page" pagination prefix multi-language setting.
- Add support for list-unsubscribe headers (though not sure I recommend them yet). 
- Improved HTML to TEXT conversion (when combined with core dev branch). 
- Add support for limiting templates of pages allowed for emails. 
- Adjust database column settings to reduce index length for expanded DB support.
- Update the message screen to be less technical, hiding developer info in fieldsets.
- Other minor bug fixes

ProMailer v7 (5 April 2019) 
- Changed subscribers list interface to use tabs. 
- Added ability to remove ALL subscribers from a list.
- Added ability to remove FILTERED subscribers from a list (matching find query).
- Added ability to IMPORT subscribers from another list.
- Added support for single and multi-select custom fields.
- Added support for checkbox custom fields.
- Added support for PW 3.0.129+ email blacklist. 
- Added several new options for custom fields: 
  https://processwire.com/store/pro-mailer/manual/#custom-fields-reference
- Added documentation for conditional placeholders:  
  https://processwire.com/store/pro-mailer/manual/#custom-fields-placeholders-and-conditionals
- Split the rather large ProcessProMailer.module into separate files/classes.   
- Fix some display issues in AdminThemeDefault and AdminThemeReno.
- Various minor bug fixes.

ProMailer beta v6 (20 March 2019)
- Add support for conditional placeholders in messages: 
  {if:fname} Hi {fname} {else} Hi friend {endif}.
- Add new more accurate preview option in Message edit screen.
- Add support for showing Gravatar for subscribers in admin.
- Add comprehensive PW hooks to ProMailerSubscribers and ProMailerEmail classes. 
- Fix issue with relative-to-absolute URL conversion in HTML email.
- Add logs quicklinks to ProMailer admin theme dropdown navigation.
- Add support for logging of IP addresses (option in module config).
- Add support for logging sent email (option in module config). 
- Improved markup-to-text conversion for ProMailerEmail. 

ProMailer beta v5 
- First public release version

   
ProMailer VIP support
---------------------
Your ProMailer service includes 1-year of VIP support through the ProcessWire 
support forum. Your account should be active upon completing your purchase. 
If for some reason it is not, please send a private message (PM) to "ryan", or 
contact us at https://processwire.com/contact/ and let us know what your forum 
name is so that we can upgrade your member access. 

- Forum: https://processwire.com/talk/forum/50-promailer-support/
- Email: ryan@processwire.com


Terms, conditions and warranty
------------------------------
This is a commercial module for ProcessWire. You are licensed to install this 
module only if you have purchased a product and support key from RCD/ProcessWire 
(Ryan Cramer Design, LLC) at https://processwire.com/talk/store/. You may not 
copy or distribute ProMailer, except on site(s) you have registered it for with 
RCD/ProcessWire. You are licensed to use this module only if you purchased it 
from RCD/ProcessWire, your 1-person web developer purchased it from RCD/ProcessWire 
for your site and installed it for you, or your multi-person web-development agency 
purchased it from RCD/ProcessWire and installed it for you. Do not distribute this 
module. Do not upload to GitHub or any other public repository or location. Only 
upload to your website where you will be using ProMailer. Staging and development
servers for your site are of course fine, as are backups. 

This service/software includes 1-year of support through the ProcessWire ProMailer
Support forum and/or email. Please notify us of your forum name so that we can upgrade
your access to the members-only ProMailer or ProDevTools support forum.

In no event shall Ryan Cramer Design LLC or ProcessWire be liable for any special, 
indirect, consequential, exemplary, or incidental damages whatsoever, including, 
without limitation, damage for loss of business profits, business interruption, 
loss of business information, loss of goodwill, or other pecuniary loss whether 
based in contract, tort, negligence, strict liability, or otherwise, arising out of 
the use or inability to use ProcessWire ProMailer, even if Ryan Cramer Design, LLC / 
ProcessWire has been advised of the possibility of such damages. 

ProMailer is provided "as-is" without warranty of any kind, either expressed or 
implied, including, but not limited to, the implied warranties of merchantability and
fitness for a particular purpose. The entire risk as to the quality and performance
of the program is with you. Should the program prove defective, you assume the cost 
of all necessary servicing, repair or correction. Should you run into any trouble 
with ProMailer, please email for support or visit the ProMailer Support forum and 
we’ll be happy to help you resolve any issues you run into.

---
ProMailer is Copyright 2019 by Ryan Cramer Design, LLC  

