<?php namespace ProcessWire;

/**
 * List architects
 *
 * This template does the exact same thing as our browse.php template,
 * so we just include that one instead duplicating code.
 *
 */

include("./browse.php"); 
