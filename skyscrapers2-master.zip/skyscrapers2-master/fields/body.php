<div class='bodycopy uk-margin-right'>
	<?php echo $value; ?>
</div>	