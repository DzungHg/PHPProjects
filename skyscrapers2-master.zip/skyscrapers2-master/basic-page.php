<?php namespace ProcessWire;

/**
 * A generic content page. On this site it's used to display the "about us" copy, 
 * but can be used for any other generic content pages. 
 *
 * Intentionally left blank:
 * We don't need to add anything here that's not already taken care of by _init.php
 *
 */

